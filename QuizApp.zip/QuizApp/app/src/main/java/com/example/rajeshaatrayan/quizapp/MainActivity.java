package com.example.rajeshaatrayan.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int score = 0;
    int wrongAnswers = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private int scoreCalculator() {
        /**
         * Validating Question Number 1
         */
        RadioButton radioButton = (RadioButton) findViewById(R.id.stroglytyped_radio_button);
        if (radioButton.isChecked()) score++;


        /**
         * Validating Question Number 2
         */
        radioButton = (RadioButton) findViewById(R.id.answe_8);
        if (radioButton.isChecked()) score++;


        /**
         * Validating Question Number 3
         */

        radioButton = (RadioButton) findViewById(R.id.boolean_literal);
        if (radioButton.isChecked()) score++;


        /**
         * Validating Question Number 4
         */

        radioButton = (RadioButton) findViewById(R.id.lang_object);
        if (radioButton.isChecked()) score++;


        /**
         * Validating Question Number 5
         */

        EditText editText = (EditText) findViewById(R.id.blank);
        String str = editText.getText().toString();
        if (str.equalsIgnoreCase("Throwable")) score++;


        /**
         * Validating Question Number 6
         */

        CheckBox checkBox1 = (CheckBox) findViewById(R.id.byte_check_box);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.int_check_box);
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.class_str);
        CheckBox checkBox4 = (CheckBox) findViewById(R.id.class_obj);
        if (checkBox1.isChecked() & checkBox2.isChecked()) {
            if (checkBox3.isChecked() | checkBox4.isChecked()) ;
            else
                score++;
        }
        return score;
    }


    public void submitMethod(View view) {
        score = 0;
        int scoreObtained = scoreCalculator();


        if (scoreObtained == 6) {
            Toast toast = Toast.makeText(this, "Congrats! you scored: " + scoreObtained + " points", Toast.LENGTH_SHORT);
            toast.show();
        } else {
            Toast toast = Toast.makeText(this, "You scored: " + scoreObtained + " points", Toast.LENGTH_SHORT);
            toast.show();
        }


    }
}
